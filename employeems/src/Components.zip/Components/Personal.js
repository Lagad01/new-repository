import React, { useState } from 'react';
import './Personal.css';
import { LiaCameraSolid } from "react-icons/lia";
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { FaCalendarAlt } from 'react-icons/fa';
export const Personal = () => {
 
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [email, setEmail] = useState('');
//   const [dob, setDob] = useState('');
  const [maritalStatus, setMaritalStatus] = useState('');
  const [gender, setGender] = useState('');
  const [nationality, setNationality] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [dob, setDob] = useState(null); 

  const CustomDatePickerInput = ({ value, onClick }) => (
    <div className="custom-datepicker-input">
      <input
        type="text"
        value={value}
        onClick={onClick}
        placeholder="Date of Birth"
        className="Dob"
      />
      <FaCalendarAlt className="calendar-icon" onClick={onClick} />
    </div>
  );

 
  return (
    <div>
      <div  className="camera">
        <LiaCameraSolid size={25} />
      </div>
      <form>
        <div className="form-row">
          <div className="form-group">
            
           <dd > <input className='fname' type="text" value={firstName} onChange={(e) => setFirstName(e.target.value)}  placeholder='First Name'/></dd>
          </div>
          <div className="form-group">
           
          <dd>  <input className='lastname' type="text" value={lastName} onChange={(e) => setLastName(e.target.value)} placeholder='Last Name' /></dd>
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
           
           <dd> <input  className= "mnumber" type="text" value={mobileNumber} onChange={(e) => setMobileNumber(e.target.value)}  placeholder='Mobile Number'/></dd>
          </div>
          <div className="form-group">
           
           <dd> <input  className="email1"type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder='Email' /></dd>
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
           
           {/* <dd><input className='Dob' type="date" value={dob} onChange={(e) => setDob(e.target.value)} placeholder='Date of Birth' /></dd>  */}
           {/* <input 
          type="text" 
          value={dob} 
          onChange={handleDateChange} 
          placeholder="Date of Birth" 
          className="Dob" 
        /> */}
      
        {/* <DatePicker
          selected={dob}
          onChange={(date) => setDob(date)}
          dateFormat="dd/MM/yyyy" // Customize date format as needed
          placeholderText="Date of Birth"
          className="Dob"
        /><FaCalendarAlt/>
        */}
         <DatePicker
          selected={dob}
          onChange={(date) => setDob(date)}
          dateFormat="dd/MM/yyyy" // Customize date format as needed
          placeholderText="Date of Birth"
          customInput={<CustomDatePickerInput />}
        />
          </div>
          <div className="form-group">
            
           <dd> <select  className="mstatus" value={maritalStatus} onChange={(e) => setMaritalStatus(e.target.value)}>
              <option value="">Marital Status</option>
              <option value="single">Single</option>
              <option value="married">Married</option>
              <option value="divorced">Divorced</option>
              <option value="widowed">Widowed</option>
            </select>
            </dd>
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
           
          <dd>  <select className='gender' value={gender} onChange={(e) => setGender(e.target.value)}>
              <option value="">Gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
            </dd>
          </div>
          <div className="form-group">
           
           <dd> <input className='Nationality' type="text" value={nationality} onChange={(e) => setNationality(e.target.value)} placeholder='Nationality' /></dd>
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            
          <dd> <textarea className='address' value={address} onChange={(e) => setAddress(e.target.value)}  placeholder='Address'/></dd> 
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
           
           <dd>
           <select className='city' value={city} onChange={(e) =>setCity (e.target.value)}>
              <option value="">City</option>
              <option value="Andhra">Hyd</option>
              <option value="Telegana">Benglore</option>
              <option value="UP">Vijayawada</option>
            
            </select></dd> 
          </div>
          <div className="form-group">
           
           <dd> <select className='state' value={state} onChange={(e) => setState(e.target.value)}>
              <option value="">State</option>
              <option value="Andhra">Andhra</option>
              <option value="Telegana">Telegana</option>
              <option value="UP">Uttarpradesh</option>
            
            </select>
            </dd>
          </div>
          <div className="form-group">
          
           <dd> 
           <select className='zname' value={zipCode} onChange={(e) => setZipCode(e.target.value)}>
              <option value="">Zip Code</option>
              <option value="Andh">67676</option>
              <option value="Telegana">789779</option>
              <option value="UP">Uttarpradesh</option>
            
            </select>


            </dd>
            <div style={{marginLeft:"24px",marginTop:"18%"}} >

<button className="nextbtn" 
type="button"
>Next</button>

<button className="cancelbtn"
type="button"
>Cancel</button>
</div>
          </div>
        </div>

      </form>
    </div>
  );
};
