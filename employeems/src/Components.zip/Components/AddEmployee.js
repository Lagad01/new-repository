import React, { useState } from 'react';
import { IoPerson } from "react-icons/io5";
import { IoBagCheckOutline } from "react-icons/io5";
import { IoDocumentTextOutline } from "react-icons/io5";
import { MdLockOutline } from "react-icons/md";
import './AddEmployee.css'; 
import { TbMathGreater } from "react-icons/tb";
import { Personal } from './Personal';
import { Professional } from './Professional';
import { Documents } from './Documents';
import { AccountAccess } from './AccountAccess';

const CustomTab = ({ title, isActive, onClick }) => (
  <div className={`custom-tab ${isActive ? 'active' : ''}`} onClick={onClick}>
    {title}
  </div>
);

export const AddEmployee = () => {
  const [activeTab, setActiveTab] = useState("personal");

  const handleTabClick = (tabKey) => {
    setActiveTab(tabKey);
  };

  return (
    <div>
      <h2>Add  New Employee</h2>
      <p className='spanemployee'>
          All Employee &nbsp;<TbMathGreater/>&nbsp;Add New Employee 
        </p>
        <div className="custom-tabs-container">
      <div className="custom-tabs">
        <CustomTab
          title={<><IoPerson /> Personal Information</>}
          isActive={activeTab === 'personal'}
          onClick={() => handleTabClick('personal')}
        />

        <CustomTab
          title={<><IoBagCheckOutline /> Professional Information</>}
          isActive={activeTab === 'professional'}
          onClick={() => handleTabClick('professional')}
        />

        <CustomTab
          title={<><IoDocumentTextOutline /> Documents</>}
          isActive={activeTab === 'documents'}
          onClick={() => handleTabClick('documents')}
        />

        <CustomTab
          title={<><MdLockOutline /> Account Access</>}
          isActive={activeTab === 'account'}
          onClick={() => handleTabClick('account')}
        />
      </div>

      <div className="tab-content">
       
        {activeTab === 'personal' && <div><Personal/></div>}
        {activeTab === 'professional' && <div className="professional"><Professional/></div>}
        {activeTab === 'documents' && <div><Documents/></div>}
        {activeTab === 'account' && <div><AccountAccess/></div>}
      </div>
    </div>
    </div>
  );
};
