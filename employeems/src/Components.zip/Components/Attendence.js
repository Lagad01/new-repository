import React from 'react'

export const Attendence = () => {
  return (
    <div>Attendence</div>
  )
}
