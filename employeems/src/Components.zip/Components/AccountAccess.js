import React from 'react'

export const AccountAccess= () => {
  return (
    <div>Account Access</div>
  )
}
