
import React from 'react'

export const Jobs = () => {
  return (
    <div>Jobs</div>
  )
}
