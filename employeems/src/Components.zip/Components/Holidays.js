import React from 'react'

export const Holidays = () => {
  return (
    <div>Holidays</div>
  )
}
