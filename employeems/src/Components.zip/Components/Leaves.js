import React from 'react'

export const Leaves = () => {
  return (
    <div>Leaves</div>
  )
}
