import React from 'react'

export const Documents = () => {
  return (
    <div>Documents </div>
  )
}
