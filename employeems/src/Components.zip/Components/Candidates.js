import React from 'react'

export const Candidates = () => {
  return (
    <div>Candidates</div>
  )
}
