import React from 'react'

export const Professional = () => {
  return (
    <div>Personal information</div>
  )
}
