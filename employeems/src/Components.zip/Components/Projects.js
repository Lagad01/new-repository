
import React from 'react';

const Projects = () => {
  return (
    <div>
      <h2>Projects</h2>
     
    </div>
  );
};

export default Projects;
