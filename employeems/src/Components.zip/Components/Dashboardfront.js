
import React from 'react'

export const DashboardHome = () => {
  return (
    <div>Home Page</div>
  )
}
