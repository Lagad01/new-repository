import React from 'react'

export const Payroll = () => {
  return (
    <div>Payroll</div>
  )
}
